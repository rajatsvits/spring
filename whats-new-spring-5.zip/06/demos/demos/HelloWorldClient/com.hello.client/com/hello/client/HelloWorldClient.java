package com.hello.client;

import com.hello.HelloWorld;

public class HelloWorldClient {

	public static void main(String[] args) {
		HelloWorld helloWorld = new HelloWorld();
		System.out.println(helloWorld.sayHelloWorld());
	}

}
