module com.hello.client {
	requires com.hello;
}