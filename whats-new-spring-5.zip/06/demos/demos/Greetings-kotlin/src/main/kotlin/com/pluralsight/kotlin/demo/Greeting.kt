package com.pluralsight.kotlin.demo

data class Greeting(val id: Long, val content: String)