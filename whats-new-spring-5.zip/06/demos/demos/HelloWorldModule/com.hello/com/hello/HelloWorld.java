package com.hello;

public class HelloWorld {

	public String sayHelloWorld () {
		return "Hello World!";
	}
	
}
