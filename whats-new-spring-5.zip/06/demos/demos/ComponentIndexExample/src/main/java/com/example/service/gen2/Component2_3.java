package com.example.service.gen2;

import org.springframework.stereotype.Component;

@Component
public class Component2_3 {


}