package com.example.service.gen3;

import org.springframework.stereotype.Component;

@Component
public class Component3_10 {


}