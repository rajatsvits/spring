package com.example.service.gen0;

import org.springframework.stereotype.Component;

@Component
public class Component0_12 {


}