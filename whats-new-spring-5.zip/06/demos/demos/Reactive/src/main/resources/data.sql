INSERT INTO person VALUES (1, 'bryan', 'bryan@test.com');
INSERT INTO person VALUES (2, 'dan', 'dan@test.com');
INSERT INTO person VALUES (3, 'alex', 'alex@test.com');
