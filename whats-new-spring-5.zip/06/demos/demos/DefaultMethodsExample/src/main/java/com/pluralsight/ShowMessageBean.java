package com.pluralsight;

public class ShowMessageBean implements MessageBean {

	public void showMessage(String msg) {
        System.out.println(msg);
    }
	
}
